# Example Package


My first python Package.
python -m build to build the dist folder.
This is a simple example package.